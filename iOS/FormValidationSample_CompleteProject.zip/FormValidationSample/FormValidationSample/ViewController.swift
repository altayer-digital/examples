//
//  ViewController.swift
//  FormValidationSample
//
//  Created by Suraj Thomas on 09/03/2020.
//  Copyright © 2020 Suraj Thomas K. All rights reserved.
//

import UIKit
import ATGValidator

class ViewController: UIViewController {

    weak var activeField: UIView?

    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var nameErrorLabel: UILabel!
    @IBOutlet private weak var nameTextField: UITextField!
    @IBOutlet private weak var numberLabel: UILabel!
    @IBOutlet private weak var numberErrorLabel: UILabel!
    @IBOutlet private weak var numberTextField: UITextField!
    @IBOutlet private weak var addressLabel: UILabel!
    @IBOutlet private weak var addressErrorLabel: UILabel!
    @IBOutlet private weak var addressTextView: UITextView!
    @IBOutlet private weak var passwordLabel: UILabel!
    @IBOutlet private weak var passwordErrorLabel: UILabel!
    @IBOutlet private weak var passwordTextField: UITextField!
    @IBOutlet private weak var confirmPasswordLabel: UILabel!
    @IBOutlet private weak var confirmPasswordErrorLabel: UILabel!
    @IBOutlet private weak var confirmPasswordTextField: UITextField!
    @IBOutlet private weak var proceedButton: UIButton!

    @IBOutlet private weak var scrollView: UIScrollView!
    @IBOutlet private weak var bottomConstraint: NSLayoutConstraint!

    let formValidator = FormValidator()

    private enum Constants {

        static let cornerRadius: CGFloat = 3.0
        static let borderWidth: CGFloat = 1.0
        static let errorColor: CGColor = UIColor.red.cgColor
        static let validColor: CGColor = UIColor.clear.cgColor
    }

    override func viewDidLoad() {

        super.viewDidLoad()

        addObserversForKeyboard()

        nameTextField.layer.cornerRadius = Constants.cornerRadius
        numberTextField.layer.cornerRadius = Constants.cornerRadius
        addressTextView.layer.cornerRadius = Constants.cornerRadius
        passwordTextField.layer.cornerRadius = Constants.cornerRadius
        confirmPasswordTextField.layer.cornerRadius = Constants.cornerRadius

        configureFormHandler()
        configureValidations()
        configureFieldErrorHandlers()
    }

    private func configureFormHandler() {

        proceedButton.isEnabled = false
        proceedButton.alpha = 0.5

        formValidator.handler = { [weak self] result in

            let isFormValid = result.status == .success
            self?.proceedButton.isEnabled = isFormValid
            self?.proceedButton.alpha = isFormValid ? 1.0 : 0.5
        }
    }

    private func configureFieldErrorHandlers() {

        nameTextField.validationHandler = { [weak self] result in

            self?.nameTextField.layer.borderColor = result.status == .failure ? Constants.errorColor : Constants.validColor
            self?.nameTextField.layer.borderWidth = result.status == .failure ? Constants.borderWidth : 0.0
            self?.nameErrorLabel.text = (result.errors?.first as? ValidationError)?.customErrorMessage
        }
        numberTextField.validationHandler = { [weak self] result in

            self?.numberTextField.layer.borderColor = result.status == .failure ? Constants.errorColor : Constants.validColor
            self?.numberTextField.layer.borderWidth = result.status == .failure ? Constants.borderWidth : 0.0
            self?.numberErrorLabel.text = (result.errors?.first as? ValidationError)?.customErrorMessage
        }
        addressTextView.validationHandler = { [weak self] result in

            self?.addressTextView.layer.borderColor = result.status == .failure ? Constants.errorColor : Constants.validColor
            self?.addressTextView.layer.borderWidth = result.status == .failure ? Constants.borderWidth : 0.0
            self?.addressErrorLabel.text = (result.errors?.first as? ValidationError)?.customErrorMessage
        }
        passwordTextField.validationHandler = { [weak self] result in

            self?.passwordTextField.layer.borderColor = result.status == .failure ? Constants.errorColor : Constants.validColor
            self?.passwordTextField.layer.borderWidth = result.status == .failure ? Constants.borderWidth : 0.0
            self?.passwordErrorLabel.text = (result.errors?.first as? ValidationError)?.customErrorMessage
        }
        confirmPasswordTextField.validationHandler = { [weak self] result in

            self?.confirmPasswordTextField.layer.borderColor = result.status == .failure ? Constants.errorColor : Constants.validColor
            self?.confirmPasswordTextField.layer.borderWidth = result.status == .failure ? Constants.borderWidth : 0.0
            self?.confirmPasswordErrorLabel.text = (result.errors?.first as? ValidationError)?.customErrorMessage
        }
    }

    private func configureValidations() {

        nameTextField.validationRules = [StringLengthRule.min(5).with(errorMessage: "Name needs to have atleast 5 characters")]
        numberTextField.validationRules = [
            StringLengthRule(min: 8, max: 12, ignoreCharactersIn: CharacterSet.whitespacesAndNewlines).with(errorMessage: "Phone number must be between 8 and 12 digits long"),
            CharacterSetRule.numbersOnly(ignoreCharactersIn: CharacterSet.whitespacesAndNewlines).with(errorMessage: "Phone number must have only numbers")
        ]
        addressTextView.validationRules = [StringLengthRule.min(20).with(errorMessage: "Address must have atleast 20 characters")]
        passwordTextField.validationRules = [
            StringLengthRule.min(6).with(errorMessage: "Password must have atleast 6 characters"),
            CharacterSetRule.containsNumber().with(errorMessage: "Password must have atleast 1 number"),
            CharacterSetRule.containsUpperCase().with(errorMessage: "Password must have atleast 1 uppercase"),
            CharacterSetRule.containsLowerCase().with(errorMessage: "Password must have atleast 1 lowercase")
        ]
        confirmPasswordTextField.validationRules = [
            StringValueMatchRule(base: passwordTextField).with(errorMessage: "Passwords does not match"),
            StringLengthRule.required().with(errorMessage: "Confirm password field cannot be empty")
        ]

        formValidator.add(nameTextField)
        formValidator.add(numberTextField)
        formValidator.add(addressTextView)
        formValidator.add(passwordTextField)
        formValidator.add(confirmPasswordTextField)
    }

    @IBAction private func didTapOnProceedButton() {

        // TODO: Perform proceed action.
    }
}

// MARK: - UITextFieldDelegate

extension ViewController: UITextFieldDelegate {

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {

        activeField = textField
        return true
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {

        if textField == activeField {
            activeField = nil
        }
        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        textField.resignFirstResponder()
        return true
    }
}

// MARK: - Keyboard handling

extension ViewController {

    private func addObserversForKeyboard() {

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow(notification:)),
            name: UIResponder.keyboardWillShowNotification, object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide(notification:)),
            name: UIResponder.keyboardWillHideNotification, object: nil
        )
    }

    @objc private func keyboardWillShow(notification: Notification) {

        if let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {

            bottomConstraint?.constant = keyboardFrame.height

            let offset = scrollView.frame.minY + 40.0

            if let field = activeField {
                if (field.frame.maxY - scrollView.contentOffset.y + offset) > keyboardFrame.minY {
                    scrollView.contentOffset.y += ((field.frame.maxY - scrollView.contentOffset.y + offset) - keyboardFrame.minY)
                } else if field.frame.minY - scrollView.contentOffset.y < 0.0 {
                    scrollView.contentOffset.y -= (field.frame.minY - scrollView.contentOffset.y + offset)
                }
            }

            let animator = UIViewPropertyAnimator(
                duration: 0.3,
                curve: .linear) {
                    self.view.layoutIfNeeded()
            }
            animator.startAnimation()
        }
    }

    @objc private func keyboardWillHide(notification: Notification) {

        bottomConstraint?.constant = 0.0
        let animator = UIViewPropertyAnimator(
            duration: 0.3,
            curve: .linear) {
                self.view.layoutIfNeeded()
        }
        animator.startAnimation()
    }
}
