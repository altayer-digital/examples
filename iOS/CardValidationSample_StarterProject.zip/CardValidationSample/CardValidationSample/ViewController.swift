//
//  ViewController.swift
//  CardValidationSample
//
//  Created by Suraj Thomas on 08/03/2020.
//  Copyright © 2020 Suraj Thomas K. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet private weak var cardNumberLabel: UILabel!
    @IBOutlet private weak var cardNumberTextField: UITextField!
    @IBOutlet private weak var cardNumberStatusLabel: UILabel!
    @IBOutlet private weak var continueButton: UIButton!

    override func viewDidLoad() {

        super.viewDidLoad()

    }
}

extension ViewController {

    @IBAction private func didTapOnContinueButton(_ sender: UIButton) {

        print("Card Number : \(cardNumberTextField.text ?? "")")
    }
}
