//
//  ViewController.swift
//  FormValidationSample
//
//  Created by Suraj Thomas on 09/03/2020.
//  Copyright © 2020 Suraj Thomas K. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    weak var activeField: UIView?

    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var nameErrorLabel: UILabel!
    @IBOutlet private weak var nameTextField: UITextField!
    @IBOutlet private weak var numberLabel: UILabel!
    @IBOutlet private weak var numberErrorLabel: UILabel!
    @IBOutlet private weak var numberTextField: UITextField!
    @IBOutlet private weak var addressLabel: UILabel!
    @IBOutlet private weak var addressErrorLabel: UILabel!
    @IBOutlet private weak var addressTextView: UITextView!
    @IBOutlet private weak var passwordLabel: UILabel!
    @IBOutlet private weak var passwordErrorLabel: UILabel!
    @IBOutlet private weak var passwordTextField: UITextField!
    @IBOutlet private weak var confirmPasswordLabel: UILabel!
    @IBOutlet private weak var confirmPasswordErrorLabel: UILabel!
    @IBOutlet private weak var confirmPasswordTextField: UITextField!
    @IBOutlet private weak var proceedButton: UIButton!

    @IBOutlet private weak var scrollView: UIScrollView!
    @IBOutlet private weak var bottomConstraint: NSLayoutConstraint!

    override func viewDidLoad() {

        super.viewDidLoad()

        addObserversForKeyboard()

    }

    @IBAction private func didTapOnProceedButton() {

        // TODO: Perform proceed action.
    }
}

// MARK: - UITextFieldDelegate

extension ViewController: UITextFieldDelegate {

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {

        activeField = textField
        return true
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {

        if textField == activeField {
            activeField = nil
        }
        return true
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        textField.resignFirstResponder()
        return true
    }
}

// MARK: - Keyboard handling

extension ViewController {

    private func addObserversForKeyboard() {

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow(notification:)),
            name: UIResponder.keyboardWillShowNotification, object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide(notification:)),
            name: UIResponder.keyboardWillHideNotification, object: nil
        )
    }

    @objc private func keyboardWillShow(notification: Notification) {

        if let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {

            bottomConstraint?.constant = keyboardFrame.height

            let offset = scrollView.frame.minY + 40.0

            if let field = activeField {
                if (field.frame.maxY - scrollView.contentOffset.y + offset) > keyboardFrame.minY {
                    scrollView.contentOffset.y += ((field.frame.maxY - scrollView.contentOffset.y + offset) - keyboardFrame.minY)
                } else if field.frame.minY - scrollView.contentOffset.y < 0.0 {
                    scrollView.contentOffset.y -= (field.frame.minY - scrollView.contentOffset.y + offset)
                }
            }

            let animator = UIViewPropertyAnimator(
                duration: 0.3,
                curve: .linear) {
                    self.view.layoutIfNeeded()
            }
            animator.startAnimation()
        }
    }

    @objc private func keyboardWillHide(notification: Notification) {

        bottomConstraint?.constant = 0.0
        let animator = UIViewPropertyAnimator(
            duration: 0.3,
            curve: .linear) {
                self.view.layoutIfNeeded()
        }
        animator.startAnimation()
    }
}
